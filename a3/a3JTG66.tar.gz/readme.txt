to run:
   compile:
      gcc -o a3 a3.c -pthread -lm
      gcc -o b3 b3.c -pthread -lm
   execute:
      ./a3
      ./b3
